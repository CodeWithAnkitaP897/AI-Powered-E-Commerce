package com.telusko.springecomai;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringEcomAiApplication {

    public static void main(String[] args) {
        SpringApplication.run(SpringEcomAiApplication.class, args);
    }

}
