package com.telusko.springecomai;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringEcomAiApplicationTests {

    @Test
    void contextLoads() {
    }

}
