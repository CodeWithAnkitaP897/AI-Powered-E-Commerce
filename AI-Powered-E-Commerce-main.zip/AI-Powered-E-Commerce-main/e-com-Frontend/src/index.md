.dark-theme{
    --root_background: #1f1f1f;}
    .light-theme{
        --root_background: white;
    }
:root{
    background-color: white;
}